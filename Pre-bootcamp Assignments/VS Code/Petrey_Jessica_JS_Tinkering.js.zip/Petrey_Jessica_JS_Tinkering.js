childHeight = 54

function displayIfChildIsAbleToRideTheRollerCoaster(height) {
    if (height > 52) {
        console.log("Get on that ride, kiddo!");
    }
    else {
        console.log("Sorry kiddo. Maybe next year.");
    }
}

displayIfChildIsAbleToRideTheRollerCoaster(childHeight)