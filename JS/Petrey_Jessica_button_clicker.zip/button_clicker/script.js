function loginStatus(element) {
    element.innerText = "Logout"
}

function removeButton(element) {
    element.remove();
}