console.log("page loaded...");

var vid = document.getElementById("smoke").muted = true; 

function play() { 
    vid.play(); 
} 
function pauseVid() { 
    vid.pause(); 
}