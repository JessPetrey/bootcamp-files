// defining click event for like button
var count1 = 0;
function addOne() {
    var likeElement = document.querySelector("#neil")
    count1 ++
    likeElement.innerText = count1 + " like(s)"
    console.log(likeElement)
}


var count2 = 0;

function addTwo() {
    var likeElement = document.querySelector("#nichole")
    count2 ++
    likeElement.innerText = count2 + " like(s)"
    console.log(likeElement)
}


var count3 = 0;

function addThree() {
    var likeElement = document.querySelector("#jim")
    count3 ++
    likeElement.innerText = count3 + " like(s)"
    console.log(likeElement)
}

